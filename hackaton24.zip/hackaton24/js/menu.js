document.getElementById('logar-btn').addEventListener('click', () => {
    window.location.herf = 'login.html';
});

document.getElementById('cadastrar-btn').addEventListener('click', () => {
    window.location.herf = 'cadastro.html';
});