document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const cpf = document.getElementById('cpf').values;
    const senha =document.getElementById('senha').values;
    const messafeElement = document.getElementById('message');

    if (!cpf || !senha){
        messafeElement.textContent = 'Favor, preencher todos os campos.';
        return;
    }

    messageElement.textContent = 'Fazendo login . . .';

    try{
        const response = await fetch('http://localhost:3030/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ cpf, senha })
        });

if (response.ok) {
    const data = await response.json();
    localStorage.setItem('token', data.token); 
    window.location.href = 'paginaInicial.html'; 
} else {
    const errorMessage = await response.text();
    messageElement.textContent = errorMessage; 
}
} catch (error) {
messageElement.textContent = 'Erro ao fazer login. Tente novamente.'; 
}
});