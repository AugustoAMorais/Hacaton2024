const express = require('express');
const cors = require('cors');
const connection = require('./db_config');
const app = express();

app.use(cors());
app.use(express.json());

const port = 3030;

app.post('/cadastrar', (req, res) => {
    const{nome, cpf, senha, tipo_usuario} = req.body

    const query = "INSERT INTO usuarios (nome, cpf,senha,tipo_usuario) VALUES(?,?,?,?)"
    connection.query(query, [nome, cpf, senha, tipo_usuario], (err, result) => {
        if (err) {
          return res.status(500).json({ success: false, message: 'Erro ao inserir produto.' });
        }
        res.json({ success: true, message: 'Produto inserido com sucesso!'});
      });
    
})


// Rota para login
app.post('/login', (req, res) => {
    const { cpf, senha } = req.body;

    const query = 'SELECT * FROM usuarios WHERE cpf = ? AND senha = ?';
    connection.query(query, [cpf, senha], (err, results) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Erro no servidor.' });
        }

        if (results.length > 0) {
            res.json({ success: true, message: 'Login bem-sucedido!', user: results[0] });
        } else {
            res.json({ success: false, message: 'Usuário ou senha incorretos!' });
        }
    });
});

// CRUD de bisturis
app.post('/bisturis', (req, res) => {
    const { nome, tipo_lamina, tipo_cabo } = req.body;
    const query = 'INSERT INTO itens_bisturi (nome, tipo_lamina, tipo_cabo) VALUES (?, ?, ?)';
    connection.query(query, [nome, tipo_lamina, tipo_cabo], (err, result) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Erro ao adicionar bisturi.' });
        }
        res.json({ success: true, message: 'Bisturi adicionado com sucesso!', id: result.insertId });
    });
});

app.get('/bisturis', (req, res) => {
    const query = 'SELECT * FROM itens_bisturi';
    connection.query(query, (err, results) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Erro ao buscar bisturis.' });
        }
        res.json({ success: true, bisturis: results });
    });
});

app.put('/bisturis/:id', (req, res) => {
    const { id } = req.params;
    const { nome, tipo_lamina, tipo_cabo } = req.body;
    const query = 'UPDATE itens_bisturi SET nome = ?, tipo_lamina = ?, tipo_cabo = ? WHERE id = ?';
    connection.query(query, [nome, tipo_lamina, tipo_cabo, id], (err) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Erro ao atualizar bisturi.' });
        }
        res.json({ success: true, message: 'Bisturi atualizado com sucesso!' });
    });
});

app.delete('/bisturis/:id', (req, res) => {
    const { id } = req.params;
    const query = 'DELETE FROM itens_bisturi WHERE id = ?';
    connection.query(query, [id], (err) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Erro ao deletar bisturi.' });
        }
        res.json({ success: true, message: 'Bisturi deletado com sucesso!' });
    });
});

// CRUD de pinças
app.post('/pincas', (req, res) => {
    const { tipo_pinca, tamanho, tipo, qtde } = req.body;
    const query = 'INSERT INTO pinca (tipo_pinca, tamanho, tipo, qtde) VALUES (?, ?, ?, ?)';
    connection.query(query, [tipo_pinca, tamanho, tipo, qtde], (err, result) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Erro ao adicionar pinça.' });
        }
        res.json({ success: true, message: 'Pinça adicionada com sucesso!', id: result.insertId });
    });
});

app.get('/pincas', (req, res) => {
    const query = 'SELECT * FROM pinca';
    connection.query(query, (err, results) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Erro ao buscar pinças.' });
        }
        res.json({ success: true, pincas: results });
    });
});

app.put('/pincas/:id', (req, res) => {
    const { id } = req.params;
    const { tipo_pinca, tamanho, tipo, qtde } = req.body;
    const query = 'UPDATE pinca SET tipo_pinca = ?, tamanho = ?, tipo = ?, qtde = ? WHERE id = ?';
    connection.query(query, [tipo_pinca, tamanho, tipo, qtde, id], (err) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Erro ao atualizar pinça.' });
        }
        res.json({ success: true, message: 'Pinça atualizada com sucesso!' });
    });
});

app.delete('/pincas/:id', (req, res) => {
    const { id } = req.params;
    const query = 'DELETE FROM pinca WHERE id = ?';
    connection.query(query, [id], (err) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Erro ao deletar pinça.' });
        }
        res.json({ success: true, message: 'Pinça deletada com sucesso!' });
    });
});

// Início do servidor
app.listen(port, () => console.log(`Servidor rodando na porta ${port}`));
