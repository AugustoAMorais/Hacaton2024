async function cadastrar(event){
    event.preventDefault()

    const nome = document.getElementById('nome').value
    const cpf = document.getElementById('cpf').value
    const senha = document.getElementById('senha').value

    const cme = document.getElementById('cme')
    const instru = document.getElementById('Instrumentador')

    let tipo_usuario = ""

    if (cme.checked == true) {
        tipo_usuario = cme.value
    } else {
        tipo_usuario = instru.value
    }

    // if(cme.checked){
    //     const cme = "cme"
    // }

    alert(tipo_usuario);

    // if(instru.checked){
    //     const instruValor = true
    // }else{
    //     const instruValor = false
    // }

    // console.log(nome, cpf, senha, cme, instruValor);

    const response = await fetch('http://localhost:3030/cadastrar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nome, cpf, senha, tipo_usuario })
      });
}